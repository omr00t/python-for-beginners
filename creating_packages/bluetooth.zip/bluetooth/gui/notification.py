def push_notification():
    print("notification.push_notification has been called.")

if __name__ == "bluetooth.gui.notification":
    print("The notification module has been imported!")
