def func1():
    print("commonui.func1 has been called!")

def func2():
    print("commonui.func2 has been called!")
    dialup()

if __name__ == "bluetooth.gui.commonui":
    print("The commonui module has been imported!")
