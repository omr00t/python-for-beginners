def dialup():
    print("dialupnetwork.dialup has been called.")


if __name__ == "bluetooth.services.dialupnetwork":
    print("The dialupnetwork module has been imported!")
