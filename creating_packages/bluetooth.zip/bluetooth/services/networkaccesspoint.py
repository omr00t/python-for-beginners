def start_access_point():
    print("networkaccesspoint.start_access_point has been called.")


if __name__ == "bluetooth.services.networkaccesspoint":
    print("The networkaccesspoint module has been imported!")
