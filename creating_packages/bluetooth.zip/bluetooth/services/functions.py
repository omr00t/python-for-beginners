def func1():
    print("functions.func1 has been called.")

def func2():
    print("functions.func2 has been called.")

def func3():
    print("functions.func3 has been called.")

if __name__ == "bluetooth.services.functions":
    print("The functions module has been imported!")
