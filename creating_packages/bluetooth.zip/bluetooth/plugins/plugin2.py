def setup():
    print("plugin2.setup has been called.")

if __name__ == "bluetooth.plugins.plugin2":
    print("The plugin2 module has been imported!")
