def setup():
    print("plugin1.setup has been called.")

if __name__ == "bluetooth.plugins.plugin1":
    print("The plugin1 module has been imported!")
